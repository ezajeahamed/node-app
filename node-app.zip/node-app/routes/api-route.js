const express = require('express');
const router = express.Router();
const ApiController = require('../controllers/api-controller');

router.post('/login', ApiController.login);
router.get('/user/list', ApiController.getUser);
router.post('/user/add', ApiController.addUser);
router.get('/user/info/:id', ApiController.getSingleData);
router.post('/user/update',ApiController.updateUser);
router.get('/user/delete/:id', ApiController.deleteUser);

module.exports = {
    route: router
}